# Exa File Transfer System

Run ``python app.py`` to start up the application.

## Requirements:

1. Python
2. Requests Module
3. CustomTkinter

- You should be working in the same directory where ``app.py`` is located.