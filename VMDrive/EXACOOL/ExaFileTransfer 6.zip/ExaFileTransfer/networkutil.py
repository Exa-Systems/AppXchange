import requests
import json
import io
from PIL import Image


def download(code, directory=None):

    url = f'https://appxchange.onrender.com/files/serve/{code}'
    response = requests.get(url)

    if response.status_code == 200:
        print(f"Downloaded {code}")
        content_disposition = response.headers.get('Content-Disposition')
        if content_disposition:
            filename = content_disposition.split("filename=")[1].strip("\"")
        else:
            filename = 'file.txt'
        try:
            if directory is not None:
                with open(f"{directory}/{filename}", 'wb') as f:
                    f.write(response.content)
            else:
                with open(f"Downloads/{filename}", 'wb') as f:
                    f.write(response.content)
        except:
            with open(filename, 'wb') as f:
                f.write(response.content)

        

                
    else:
        raise Exception("Invalid response")

def upload(filename):
    file = open(filename, 'rb')
    url = "https://appxchange.onrender.com/files/upload"
    test_res = requests.post(url, files = {"file": file})
    if test_res.ok:
        print("File uploaded successfully!")
        return test_res.text
    else:
        print(" Please Upload again ! ")

def auth(user, pwd):
    url = "https://appxchange.onrender.com/auth"
    res = requests.post(url, {
        "username":user,
        "password":pwd
    })
    print(res.text)
    if res.text == "AUTH_ACCEPT":
        return True
    else:
        return False
    
def fetchApps():
    url = "https://appxchange.onrender.com/appserve"
    res = requests.get(url)
    print(res.text)
    return json.loads(res.text)

def loadStaticImg(path):
    url = f'https://appxchange.onrender.com/static/{path}'
    r = requests.get(url, stream=True)
    if r.status_code == 200:
        i = Image.open(io.BytesIO(r.content))
        
        
    return i




