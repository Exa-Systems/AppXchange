import tkinter
import tkinter.messagebox
import customtkinter
import networkutil
import pathlib
import webbrowser
from PIL import Image
import json

import os
import sys
from async_tkinter_loop import async_handler, async_mainloop
from appdirs import *

VERSION = "0.1.6a"

def config(key, value):
  
  con_dir = user_data_dir("AppXchange", "Sarang Park", version=VERSION)
  conf = os.path.join(con_dir, "config.json")
  if not os.path.exists(con_dir):
    os.makedirs(con_dir)
    if not os.path.exists(conf):
        with open(conf,"w") as f:
            f.write('{"user": "", "password": "", "directory": "", "mode": "Light"}')
  try:
    with open(conf, "r") as f:
        dat = json.load(f)
  except:
    with open(conf,"w") as f:
        f.write('{"user": "", "password": "", "directory": "", "mode": "Light"}')

  dat[key] = value
  with open(conf, "w") as f:
    json.dump(dat, f)
  
def read_config():
  
  con_dir = user_data_dir("AppXchange", "Sarang Park", version=VERSION)
  conf = os.path.join(con_dir, "config.json")

  if not os.path.exists(con_dir):
    os.makedirs(con_dir)
    if not os.path.exists(conf):
        with open(conf,"w") as f:
            f.write('{"user": "", "password": "", "directory": "", "mode": "Light"}')
  try:
    with open(conf, "r") as f:
        dat = json.load(f)
  except:
    with open(conf,"w") as f:
        f.write('{"user": "", "password": "", "directory": "", "mode": "Light"}')
  with open(conf, "r") as f:
    return json.load(f)

  

def resource_path(relative_path):

    if hasattr(sys, '_MEIPASS'):
        print(os.listdir(sys._MEIPASS))
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

customtkinter.set_appearance_mode("Light")  # Modes: "System" (standard), "Dark", "Light"
customtkinter.set_default_color_theme("dark-blue")  # Themes: "blue" (standard), "green", "dark-blue"
class AppFrame(customtkinter.CTkFrame):
    def __init__(self, master, config,main, **kwargs):
        super().__init__(master, **kwargs)

        # add widgets onto the frame, for example:
        self.appim = customtkinter.CTkImage(light_image=networkutil.loadStaticImg("logo/"+config["logo"]), size=(60,60))
        self.appicon = customtkinter.CTkLabel(self, image=self.appim, text="") 
        self.appicon.grid(row=0, column=0, pady = 10, sticky="w")

        self.detailStack = customtkinter.CTkFrame(self, fg_color="transparent")
        self.detailStack.grid(row=0, column=1)

        self.applabel = customtkinter.CTkLabel(self.detailStack, text=config["name"], font=customtkinter.CTkFont(size=17))
        self.applabel.grid(row=0, column=0, padx=20, sticky="w")

        self.complabel = customtkinter.CTkLabel(self.detailStack, text=config["company"], text_color="#898989",  font=customtkinter.CTkFont(size=10))
        self.complabel.grid(row=1, column=0, padx=20, sticky="w")

        btn = customtkinter.CTkButton(self,text=f"Download", command=lambda: main.download(config["code"]), fg_color="#5cb85c", hover_color="#28a745")
        btn.grid(row=0, column=3, padx =10, pady=3, sticky="e")

        main.update()
        # get appscroll width]
        wApp = 1
        while wApp == 1:
            main.update()
            wApp = main.appscroll.winfo_width()
        epsilon = 0.5
        wCApp = wApp * epsilon

        while self.detailStack.winfo_width() == 1:
            main.update()
        wCApp = wCApp - self.detailStack.winfo_width()

        
        print(wCApp)


        self.grid_columnconfigure(2, minsize=wCApp)

        

class App(customtkinter.CTk):

  def __init__(self):
    super().__init__()
    self.auth = 0


    feat = read_config()
    
    self.toplevel_window = None
    self.home_dir = str(pathlib.Path(__file__).parent.resolve())
    self.dir = None

    
      
    
        

    
    


    # configure window
    self.title(f"Appxchange {VERSION}")
    self.geometry(f"{1100}x{580}")
    self.filename = "welcome.md"
    # configure grid layout (4x4)
    self.grid_columnconfigure(1, weight=1)
    self.grid_columnconfigure((2, 3), weight=0)
    self.grid_rowconfigure((0, 1, 2), weight=1)

    # create sidebar frame with widgets
    self.sidebar_frame = customtkinter.CTkFrame(self,
                                                width=140,
                                                corner_radius=0)
    self.sidebar_frame.grid(row=0, column=0, rowspan=4, sticky="nsew")
    self.sidebar_frame.grid_rowconfigure(4, weight=1)
    self.logo_label = customtkinter.CTkLabel(self.sidebar_frame,
                                             text="AppXchange",
                                             font=customtkinter.CTkFont(
                                               size=30, weight="bold"))
    self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10))

    self.cwdlab = customtkinter.CTkLabel(self.sidebar_frame,
                                         text="No Directory Selected",
                                         font=customtkinter.CTkFont(
                                           size=15, weight="normal"),
                                         anchor="w")
    self.cwdlab.grid(row=1, column=0, padx=20, pady=(20, 10))

    self.dirButton = customtkinter.CTkButton(self.sidebar_frame,
                                             text="Choose Save Directory...",
                                             command=self.askdir,
                                             anchor="w")
    self.dirButton.grid(row=2, column=0, padx=0, pady=(0, 0))
    self.appearance_mode_label = customtkinter.CTkLabel(
      self.sidebar_frame, text="Appearance Mode:", anchor="w")
    self.appearance_mode_label.grid(row=5, column=0, padx=20, pady=(0, 0))
    self.appearance_mode_optionemenu = customtkinter.CTkOptionMenu(
      self.sidebar_frame,
      values=["Light", "Dark", "System"],
      command=self.change_appearance_mode_event)
    self.appearance_mode_optionemenu.set(feat["mode"])
    customtkinter.set_appearance_mode(feat["mode"]) 
    self.appearance_mode_optionemenu.grid(row=6,
                                          column=0,
                                          padx=20,
                                          pady=(10, 10))
    self.scaling_label = customtkinter.CTkLabel(self.sidebar_frame,
                                                text="UI Scaling:",
                                                anchor="w")
    self.scaling_label.grid(row=7, column=0, padx=20, pady=(10, 0))
    self.scaling_optionemenu = customtkinter.CTkOptionMenu(
      self.sidebar_frame,
      values=["80%", "90%", "100%", "110%", "120%"],
      command=self.change_scaling_event)
    self.scaling_optionemenu.grid(row=8, column=0, padx=20, pady=(10, 20))

    # create tabview
    self.tabview = customtkinter.CTkTabview(self)
    self.tabview.grid(row=0,
                      column=1,
                      padx=(20, 20),
                      pady=(20, 20),
                      sticky="nsew")
    self.tabview.add("Upload")
    self.tabview.add("Download")
    self.tabview.add("Apps")
    self.nOf = 0

    self.tabview.tab("Upload").grid_columnconfigure(
      0, weight=1)  # configure grid of individual tabs
    self.tabview.tab("Download").grid_columnconfigure(0, weight=1)
    self.tabview.tab("Apps").grid_columnconfigure(0, weight=1)

    self.file_label = customtkinter.CTkLabel(
      self.tabview.tab("Upload"),
      text="No File Selected",
      font=customtkinter.CTkFont(size=15))
    self.file_label.grid(row=0, column=0, padx=20, pady=(15, 15))
    self.combobox_1 = customtkinter.CTkButton(self.tabview.tab("Upload"),
                                              text="Find File...",
                                              command=self.askFile)
    self.combobox_1.grid(row=1, column=0, pady=(10, 10))
    self.string_input_button = customtkinter.CTkButton(
      self.tabview.tab("Upload"), text="Upload!", command=self.upload)
    self.string_input_button.grid(row=2, column=0, padx=20, pady=(10, 10))

    
    self.downloadcode = customtkinter.CTkEntry(self.tabview.tab("Download"),
                                               placeholder_text="Code...")
    self.downloadcode.grid(row=1, column=0, pady=(10, 10))
    self.string_input_button_2 = customtkinter.CTkButton(
      self.tabview.tab("Download"), text="Download!", command=self.download)
    self.string_input_button_2.grid(row=2, column=0, padx=20, pady=(10, 10))

    self.titlelabel = customtkinter.CTkLabel(self.tabview.tab("Apps"),
                                             text="New Releases",
                                             font=customtkinter.CTkFont(
                                               size=18, weight="normal"),
                                             anchor="w")
    self.titlelabel.grid(row=0, column=0, padx=10, sticky="w")

    self.appscroll = customtkinter.CTkScrollableFrame(self.tabview.tab("Apps"),
                                                      orientation="vertical")
    self.appscroll.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")

    if feat["directory"] != "":
      self.dir = pathlib.Path(feat["directory"])
      self.askdir(skip=True)

    if feat["user"] != "":
      if networkutil.auth(feat["user"], feat["password"]):
        self.auth = 1

    appobjects = networkutil.fetchApps()
    i = 0
    btns = []
    for app in appobjects:
        self.my_frame = AppFrame(master=self.appscroll, config=app, main = self)
        self.my_frame.grid(row=i, column=0, sticky="nsew")

        
        
        # setattr(self, f'AppLabel ({app["name"]})', customtkinter.CTkLabel(self.appscroll,text=app["name"]))
        # getattr(self, f'AppLabel ({app["name"]})').grid(row=i, column=0, sticky="w")
        
        # setattr(self, f'command ({app["name"]})', app["code"])
        # #print("SETTING", app["code"], app["name"])
        # btn = customtkinter.CTkButton(self.appscroll,text=f"Download", command=lambda x=i: self.download(appobjects[x]["code"]), fg_color="#5cb85c", hover_color="#28a745")
        # btn.grid(row=i, column=1, padx =10, pady=3)
        # btns.append(btn)
        i+= 1

    

    if self.auth == 0:
      self.authenticationProcess()
    else:
      self.enable_all()
      self.file_label.configure(text="No File Selected")
    
    

  def authenticationProcess(self):
    self.file_label.configure(
      text="Authentication is required for this feature.")

    self.disable_all()

    def login(window, user, pw):
      
      if not networkutil.auth(user, pw):
        self.nOf += 1
        if self.nOf == 5:
          tkinter.messagebox.showerror(
            title="Hmm",
            message=
            "Maybe try resetting your password. If you don't know your password, you can ask your administrator."
          )
        elif self.nOf == 6:
          tkinter.messagebox.showerror(
            title="Reset Password",
            message=
            "Please reset your password. Do not attempt to log in."
          )
        elif self.nOf == 7:
          tkinter.messagebox.showerror(
            title="Stop.",
            message=
            "Please reset your password at our website. There will be consequences if you continue."
          )
        elif self.nOf == 8:
          tkinter.messagebox.showinfo(
            title="Sorry",
            message="Sorry, but are you... stupid? We won't let you in. Please do not proceed.")
        elif self.nOf == 9:
          tkinter.messagebox.showerror(
            title="fact",
            message=
            "The fact that you can't follow simple instructions show how incredibly stupid you are."
          )
        elif self.nOf == 10:
          tkinter.messagebox.showerror(
            title="fact",
            message=
            "you add no value to society."
          )
        elif self.nOf == 11:
          tkinter.messagebox.showinfo(
            title="policy",
            message=
            "stop it. our authentication servers have a non-tolerance policy for idiots like you!"
          )
        elif self.nOf == 12:
          import socket   
          hostname=socket.gethostname()   
          IPAddr=socket.gethostbyname(hostname) 
          tkinter.messagebox.showinfo(
            title="lmaoo",
            message=f"Bro has room temperature IQ 💀💀"
          )
        elif self.nOf == 13:
          import socket   
          hostname=socket.gethostname()   
          IPAddr=socket.gethostbyname(hostname) 
          tkinter.messagebox.showinfo(
            title="Hi",
            message=f"Hello, {IPAddr}. Your IP will be shared to some 3rd party services. To learn more, visit https://www.youtube.com/watch?v=dQw4w9WgXcQ"
          )
        elif self.nOf > 13:
          import math
          tkinter.messagebox.showinfo(
            title="Warning",
            message=f"{(self.nOf-1) * 5 + 2 + int(math.log(self.nOf-1))} people saw your IP address!"
          )
        
        

        

        tkinter.messagebox.showinfo(
          title="Incorrect Password!",
          message=f"Incorrect Password or Username. ({self.nOf}/4)")
        return
      tkinter.messagebox.showinfo(title="Success!",
                                  message=f"Logged in successfully")
      self.enable_all()
      self.auth = 1
      self.file_label.configure(text="No File Selected")
      if self.rembe.get() == 1:
        config("user", user)
        config("password", pw)
        

        
      window.destroy()

    def callback(url):
      webbrowser.open_new(url)

    loginWin = customtkinter.CTkToplevel()
    loginWin.geometry("500x350")

    loginWin.title("Login!")
    loginWin.mainF = customtkinter.CTkFrame(master=loginWin)

    loginWin.mainF.pack(pady=20, padx=60, fill="both", expand=True)

    loginWin.label = customtkinter.CTkLabel(loginWin.mainF,
                                            text="Login to your Exa Account",
                                            font=customtkinter.CTkFont(
                                              size=20, weight="bold"))
    loginWin.label.pack(padx=20, pady=(20, 0))

    loginWin.labellink = customtkinter.CTkLabel(
      loginWin.mainF,
      text="Don't Have an Account? Make one!",
      font=customtkinter.CTkFont(size=15, weight="normal"),
      text_color="#3366CC",
      cursor="hand2")
    loginWin.labellink.pack(pady=0)
    loginWin.labellink.bind(
      "<Button-1>",
      lambda x: callback("https://exacollection.exa-team.repl.co/signup"))

    loginWin.username = customtkinter.CTkEntry(loginWin.mainF,
                                               placeholder_text="Username")
    loginWin.username.pack(padx=12, pady=10)

    loginWin.password = customtkinter.CTkEntry(loginWin.mainF,
                                               placeholder_text="Password",
                                               show="*")
    loginWin.password.pack(padx=12, pady=10)

    loginWin.submit = customtkinter.CTkButton(
      loginWin.mainF,
      text="Login",
      command=lambda: login(loginWin, loginWin.username.get(),
                            loginWin.password.get()))
    loginWin.submit.pack(padx=12, pady=10)

    self.rembe = tkinter.IntVar(self, 0)

    loginWin.checkbox = customtkinter.CTkCheckBox(loginWin.mainF,
                                                  text="Remember Me", variable=self.rembe)
    loginWin.checkbox.pack(padx=12, pady=10)



  def open_input_dialog_event(self):
    dialog = customtkinter.CTkInputDialog(text="Type in a number:",
                                          title="CTkInputDialog")
    print("CTkInputDialog:", dialog.get_input())

  def change_appearance_mode_event(self, new_appearance_mode: str):
    if new_appearance_mode == "Dark":
      config("mode", "Dark")
      customtkinter.set_default_color_theme("dark-blue")
    else:
      config("mode", "Light")
      customtkinter.set_default_color_theme("blue")
    customtkinter.set_appearance_mode(new_appearance_mode)

  def change_scaling_event(self, new_scaling: str):
    new_scaling_float = int(new_scaling.replace("%", "")) / 100
    customtkinter.set_widget_scaling(new_scaling_float)

  def sidebar_button_event(self):
    print("sidebar_button click")

  def upload(self):
    if self.auth == 0:
      webbrowser.open_new("https://exacollection.exa-team.repl.co/signup")
      return
    res = networkutil.upload(self.filename)
    self.file_label.configure(text=f"Code: {res}")

  def askFile(self):
    if self.auth == 0:
      self.authenticationProcess()
      return
    filename = tkinter.filedialog.askopenfilename()
    self.file_label.configure(text=filename)

    self.filename = filename

  def download(self, other_code=None):
    
    try:
      if other_code is None:
        code = self.downloadcode.get()
      else:
        code = other_code
      networkutil.download(code, self.dir)
      tkinter.messagebox.showinfo(
        title="Download Success!",
        message=f"Downloaded content with code: {code}")
    except:
      tkinter.messagebox.showinfo(
        title="Failed!",
        message=f"Failed whilst downloading content with code: {code}")

  def askdir(self,skip=False):
    if not skip:
      self.dir = tkinter.filedialog.askdirectory(initialdir=self.dir)
    if self.dir:
      fmt = "../" + "/".join(str(self.dir).split("/")[-2:])
      if len(fmt) > 23: fmt = "..." + fmt[-20:]
      self.cwdlab.configure(text=fmt)
      
      config("directory", str(self.dir))
    else:
      tkinter.messagebox.showerror('Error', 'Error: Please enter a directory.')
      self.dir = self.home_dir

  def disable_all(self):
    self.combobox_1.configure(text="Login")
    self.string_input_button.configure(text="Signup")

  def enable_all(self):
    self.combobox_1.configure(text="Find File...")
    self.string_input_button.configure(text="Upload!")


if __name__ == "__main__":
  app = App()
  async_mainloop(app)
  
